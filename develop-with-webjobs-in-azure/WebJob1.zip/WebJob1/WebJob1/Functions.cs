﻿using ImageProcessor.Imaging.Formats;
using ImageProcessor;
using System.Drawing;
using System.IO;
using Microsoft.Azure.WebJobs;

namespace Thumbnailer
{
    public class Functions
    {
        private static void Resize(int width, Stream input, Stream output)
        {
            using (var factory = new ImageFactory(preserveExifData: true))
            using (var memory = new MemoryStream())
            {
                factory.Load(input)
                  .Resize(new Size(width, 0))
                  .Format(new JpegFormat { Quality = 75 })
                  .Save(memory);

                memory.CopyTo(output);
            }
        }

        public static void Create640x([BlobTrigger("images/{name}")] Stream input,
            [Blob("thumbs/640x/{name}", FileAccess.Write)] Stream output)
        {
            Resize(640, input, output);
        }

        public static void Create240x([BlobTrigger("images/{name}")] Stream input,
            [Blob("thumbs/240x/{name}", FileAccess.Write)] Stream output)
        {
            Resize(240, input, output);
        }

        // This function will get triggered/executed when a new message is written 
        // on an Azure Queue called queue.
        public static void ProcessQueueMessage([QueueTrigger("queue")] string message, TextWriter log)
        {
            log.WriteLine(message);
        }
    }
}

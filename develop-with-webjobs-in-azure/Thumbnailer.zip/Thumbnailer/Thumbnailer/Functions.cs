﻿using ImageProcessor.Imaging.Formats;
using ImageProcessor;
using System.Drawing;
using System.IO;
using Microsoft.Azure.WebJobs;

namespace Thumbnailer
{
    public class Functions
    {
        private static void Resize(int width, Stream input, Stream output)
        {
            using (var factory = new ImageFactory(preserveExifData: true))
            using (var memory = new MemoryStream())
            {
                factory.Load(input)
                  .Resize(new Size(width, 0))
                  .Format(new JpegFormat { Quality = 75 })
                  .Save(memory);

                memory.CopyTo(output);
            }
        }

        public static void ThumbIt([BlobTrigger("images/{name}")] Stream input,
            [Blob("thumbnails/{name}", FileAccess.Write)] Stream output)
        {
            Resize(250, input, output);
        }
    }
}
